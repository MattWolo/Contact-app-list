import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import Login from './components/Auth';
import ContactList from './components/ContactList';
import ContactDetails from './components/ContactDetails';
import ContactForm from './components/ContactForm';
import { getContacts } from './api';

function App() {
    // State to track if user is authenticated
    const [authenticated, setAuthenticated] = useState(false);
    // State to track the currently selected contact's ID
    const [selectedContactId, setSelectedContactId] = useState(null);
    // State to store the list of contacts
    const [contacts, setContacts] = useState([]);

    // Function to fetch contacts from the API
    const fetchContacts = async () => {
        try {
            const response = await getContacts();
            setContacts(response.data);
        } catch (error) {
            console.error("Failed to fetch contacts:", error);
        }
    };

    // Fetch contacts when the component mounts
    useEffect(() => {
        fetchContacts();
    }, []);

    // Function to refresh contacts list and optionally clear selected contact
    const refreshContacts = (clearSelection = false) => {
        if (clearSelection) setSelectedContactId(null); // Clear selected contact if specified
        fetchContacts(); // Refresh contacts from API
    };

    return (
        <Router>
            <div>
                {/* Show login form if user is not authenticated */}
                {!authenticated && (
                    <Login 
                        setAuthenticated={setAuthenticated} // Function to update auth state
                        refreshContacts={refreshContacts} // Function to refresh contacts after login
                    />
                )}

                {/* Render Contact List component to display contacts */}
                <ContactList 
                    contacts={contacts} // Pass contacts to display in the list
                    setSelectedContactId={setSelectedContactId}
                    isLoggedIn={authenticated} // Pass auth status
                />

                {/* Render Contact Details component if a contact is selected */}
                {selectedContactId && (
                    <ContactDetails 
                        contactId={selectedContactId} // Pass ID of selected contact
                        onContactDeleted={() => refreshContacts(true)} // Refresh contacts after deletion
                        isLoggedIn={authenticated} // Pass auth status
                    />
                )}

                {/* Show Contact Form for adding/editing contacts if user is authenticated */}
                {authenticated && (
                    <ContactForm 
                        onSave={() => refreshContacts(true)} // Refresh contacts after form submission
                    />
                )}
            </div>
        </Router>
    );
}

export default App;