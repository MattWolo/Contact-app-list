import React from 'react';

function ContactList({ contacts, setSelectedContactId}) { // Add contacts as a prop

    return (
        <div>
            <h2>Lista kontaktów</h2>
            <ul>
                {contacts.length === 0 ? (
                    <li>Brak kontaktów</li> // Show a message if there are no contacts
                ) : (
                    contacts.map(contact => (
                        <li key={contact.id} onClick={() => setSelectedContactId(contact.id)}>
                            {contact.firstName} {contact.lastName}
                        </li>
                    ))
                )}
            </ul>
        </div>
    );
}

export default ContactList;