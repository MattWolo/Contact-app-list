import React, { useState } from 'react';
import { createContact, updateContact } from '../api';
import { validatePassword } from '../utils/validatePassword';

// Form component for adding or editing a contact
function ContactForm({ contact, onSave }) {

    // Initial form data for new contacts
    const initialFormData = {
        firstName: '',
        lastName: '',
        email: '',
        password: '',
        categoryString: '',
        subCategoryString: '',
        phoneNumber: '',
        dateOfBirth: '',
    };

    const [formData, setFormData] = useState(contact || {}); // Holds form input data, defaults to contact data if provided
    const [passwordError, setPasswordError] = useState("");

    // Handle form input changes
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    // Handle form submission for creating or updating a contact
    const handleSubmit = async (e) => {
        e.preventDefault();

        const errorMessage = validatePassword(formData.password);
        if (errorMessage) {
            setPasswordError(errorMessage);
            return;
        } else {
            setPasswordError("");
        }

        // Update if editing, else create new contact
        if (contact) {
            await updateContact(contact.id, formData);
        } else {
            await createContact(formData);
        }
        
        setFormData(initialFormData); // Reset form inputs after submission
        onSave(); // Callback to refresh contact list in parent component
    };

    return (
        <form onSubmit={handleSubmit}>
            <h2>{contact ? "Edytuj Kontakt" : "Dodaj Kontakt"}</h2>
            <input
                type="text"
                name="firstName"
                value={formData.firstName || ''}
                onChange={handleChange}
                placeholder="Imię"
            />
            <input
                type="text"
                name="lastName"
                value={formData.lastName || ''}
                onChange={handleChange}
                placeholder="Nazwisko"
            />
            <input
                type="email"
                name="email"
                value={formData.email || ''}
                onChange={handleChange}
                placeholder="E-mail"
            />
            <input
                type="password"
                name="password"
                value={formData.password || ''}
                onChange={handleChange}
                placeholder="Hasło"
            />
            {passwordError && <p style={{ color: 'red' }}>{passwordError}</p>}
            <select
                name="categoryString"
                value={formData.categoryString || ''}
                onChange={handleChange}
            >
                <option value="">Wybierz kategorię</option>
                <option value="służbowy">Służbowy</option>
                <option value="prywatny">Prywatny</option>
                <option value="inny">Inny</option>
            </select>
            
            {/* Show subcategory options based on selected category */}
            {formData.categoryString === 'służbowy' && (
                <select
                    name="subCategoryString"
                    value={formData.subCategoryString || ''}
                    onChange={handleChange}
                >
                    <option value="">Wybierz podkategorię</option>
                    <option value="szef">Szef</option>
                    <option value="klient">Klient</option>
                    <option value="współpracownik">Współpracownik</option>
                </select>
            )}
            {formData.categoryString === 'inny' && (
                <input
                    type="text"
                    name="subCategoryString"
                    value={formData.subCategoryString || ''}
                    onChange={handleChange}
                    placeholder="Podkategoria"
                />
            )}
            <input
                type="tel"
                name="phoneNumber"
                value={formData.phoneNumber || ''}
                onChange={handleChange}
                placeholder="Telefon"
            />
            <input
                type="date"
                name="dateOfBirth"
                value={formData.dateOfBirth || ''}
                onChange={handleChange}
                placeholder="Data Urodzenia"
            />
            <button type="submit">Zapisz</button>
        </form>
    );
}

export default ContactForm;
