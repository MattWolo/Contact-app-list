import React, { useEffect, useState } from 'react';
import { getContact, deleteContact } from '../api';
import ContactForm from './ContactForm';

// Component to display contact details, allow editing, deleting, and re-fetching contact data
function ContactDetails({ contactId, onContactDeleted, isLoggedIn }) {
    const [contact, setContact] = useState(null);
    const [isEditing, setIsEditing] = useState(false);

    // Fetch contact data when contactId changes
    useEffect(() => {
        const fetchContact = async () => {
            const response = await getContact(contactId);
            setContact(response.data);
        };

        setIsEditing(false); // Ensure editing mode is off when component loads
        fetchContact();
    }, [contactId]);

    // Fetch updated contact data and refresh the contacts list
    const handleFetch = async () => {
        try {
            const updatedContact = await getContact(contactId);
            setContact(updatedContact.data);
            onContactDeleted();
        } catch (error) {
            console.error("Failed to fetch updated contact:", error);
        }
    };

    // Delete contact and trigger list refresh in parent component
    const handleDelete = async () => {
        await deleteContact(contactId);
        onContactDeleted();
    };

    // Toggle editing mode
    const handleEdit = () => {
        setIsEditing(true);
    };

    // Save contact changes, update local state, and close edit form
    const handleSave = async () => {
        setIsEditing(false);
        const updatedContact = await getContact(contactId);
        setContact(updatedContact.data);
        onContactDeleted();
    };

    // Render loading message until contact data is fetched
    if (!contact) return <div>Ładowanie...</div>;

    return (
        <div>
            <h2>Szczegóły kontaktu</h2>
            <p>Imię: {contact.firstName}</p>
            <p>Nazwisko: {contact.lastName}</p>
            <p>Email: {contact.email}</p>
            <p>Telefon: {contact.phoneNumber}</p>
            <p>Kategoria: {contact.categoryString}</p>
            <p>Podkategoria: {contact.subCategoryString}</p>
            <p>Data Narodzin: {contact.dateOfBirth}</p>

            {/* Show buttons for logged-in users */}
            {isLoggedIn && (
                <>
                    <button onClick={handleDelete}>Usuń kontakt</button>
                    <button onClick={handleEdit}>Edytuj kontakt</button>
                    <button onClick={handleFetch}>Odśwież</button>
                </>
            )}

            {/* Display editing form if in editing mode */}
            {isEditing && (
                <ContactForm contact={contact} onSave={handleSave} />
            )}
        </div>
    );
}

export default ContactDetails;