import React, { useState } from 'react';
import { login, createContact } from '../api';
import { validatePassword } from '../utils/validatePassword';

// Login component, handles both login and registration
function Login({ setAuthenticated }) {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showRegister, setShowRegister] = useState(false);
    const [confirmPassword, setConfirmPassword] = useState('');
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [categoryString, setCategoryString] = useState('');
    const [subCategoryString, setSubCategoryString] = useState('');
    const [phoneNumber, setPhoneNumber] = useState('');
    const [dateOfBirth, setDateOfBirth] = useState('');
    const [passwordError, setPasswordError] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    
    const handleLogin = async (e) => {
        e.preventDefault();
        setIsSubmitting(true); // Disable the button while logging in
        try {
            const token = await login(email, password); // Call login API with email and password
            setAuthenticated(true); // Set the user as authenticated on successful login
        } catch (error) {
            console.error("Error details:", error);
            alert("Logowanie nie powiodło się.");
        } finally {
            setIsSubmitting(false); // Re-enable the button
        }
    };

    // Handles the registration process
    const handleRegister = async (e) => {
        e.preventDefault();
        if (password !== confirmPassword) {
            alert("Hasła nie są zgodne.");
            return;
        }

        // Validate the password before registration
        const error = validatePassword(password);
        if (error) {
            setPasswordError(error);
            return;
        } else {
            setPasswordError('');
        }
    
        try {
            const data = { email, password, firstName, lastName, categoryString, subCategoryString, phoneNumber, dateOfBirth };
            await createContact(data); // Call the registration API
            alert("Rejestracja zakończona sukcesem! Możesz się teraz zalogować.");
            setShowRegister(false); // Hide registration fields after successful registration
        } catch (error) {
            alert("Rejestracja nie powiodła się.");
        }
    };

    // Updates category and clears subcategory if category changes
    const handleCategoryChange = (e) => {
        const selectedCategory = e.target.value;
        setCategoryString(selectedCategory);
        setSubCategoryString('');
    };

    return (
        <div>
            {/* Conditional rendering of the form title based on whether it's registration or login */}
            <form onSubmit={showRegister ? handleRegister : handleLogin}>
                <h2>{showRegister ? "Rejestracja" : "Login"}</h2>
                
                {/* Fields for registration form */}
                {showRegister && (
                    <>
                        <input type="text" value={firstName} onChange={(e) => setFirstName(e.target.value)} placeholder="Imię" />
                        <input type="text" value={lastName} onChange={(e) => setLastName(e.target.value)} placeholder="Nazwisko" />
                        <select value={categoryString} onChange={handleCategoryChange}>
                            <option value="">Wybierz kategorię</option>
                            <option value="służbowy">Służbowy</option>
                            <option value="prywatny">Prywatny</option>
                            <option value="inny">Inny</option>
                        </select>
                        {/* Conditional rendering of subcategory */}
                        {categoryString === 'służbowy' && (
                            <select value={subCategoryString} onChange={(e) => setSubCategoryString(e.target.value)}>
                                <option value="">Wybierz podkategorię</option>
                                <option value="szef">Szef</option>
                                <option value="klient">Klient</option>
                                <option value="współpracownik">Współpracownik</option>
                            </select>
                        )}
                        {categoryString === 'inny' && (
                            <input type="text" value={subCategoryString} onChange={(e) => setSubCategoryString(e.target.value)} placeholder="Podkategoria" />
                        )}
                        <input type="tel" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} placeholder="Telefon" />
                        <input type="date" value={dateOfBirth} onChange={(e) => setDateOfBirth(e.target.value)} placeholder="Data urodzenia" />
                    </>
                )}
                
                {/* Common fields for both login and registration */}
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Hasło" />
                {passwordError && <p style={{ color: 'red' }}>{passwordError}</p>} {/* Display password error if present */}
                
                {showRegister && (
                    <input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="Potwierdź hasło" />
                )}
                
                <button type="submit">{showRegister ? "Zarejestruj się" : "Zaloguj się"}</button>
                
                {!showRegister && (
                    <button type="button" onClick={() => setShowRegister(true)}>Rejestracja</button>
                )}
                {showRegister && (
                    <button type="button" onClick={() => setShowRegister(false)}>Powrót do logowania</button>
                )}
            </form>
        </div>
    );
}

export default Login;