import axios from 'axios';

// Create an instance of axios with a base URL from environment variables
const api = axios.create({
    baseURL: process.env.REACT_APP_API_URL, // API base URL
});

// Function to retrieve the auth token from local storage
const getAuthToken = () => localStorage.getItem('token');

// Login function to authenticate user and store token in local storage
export const login = async (email, password) => {
    try {
        const response = await api.post('/Auth/login', { email, password });

        // Extract token from response based on backend's format
        const token = response.data.token;

        if (token) {
            localStorage.setItem('token', token); // Save token in local storage
            return token;
        } else {
            throw new Error("Token is undefined");
        }
    } catch (error) {
        console.error("Login error:", error);
        throw error;
    }
};

// API request to get the list of all contacts
export const getContacts = () => api.get('/Contact');

// API request to get a specific contact by ID
export const getContact = (id) => api.get(`/Contact/${id}`);

// API request to create a new contact (registers user data)
export const createContact = (data) => api.post('/Auth/register', data);

// Update contact details based on contact ID, includes authorization header
export const updateContact = async (id, data) => {
    const token = getAuthToken();
    if (!token) {
        throw new Error("Unauthorized: No token available");
    }

    try {
        // Send PUT request to update contact with authorization headers
        const response = await api.put(`/Contact/${id}`, data, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error updating contact:", error);
        throw error;
    }
};

// Delete a contact by ID, includes authorization header
export const deleteContact = (id) => {
    const token = getAuthToken();
    if (!token) {
        // Optionally handle missing token (redirect to login, show message, etc.)
        throw new Error("Unauthorized: No token available");
    }
    try {
        // Send DELETE request with authorization headers
        return api.delete(`/Contact/${id}`, {
            headers: {
                'Authorization': `Bearer ${token}`, // Include token in request headers
                'Content-Type': 'application/json'
            }
        });
    } catch (error) {
        console.error("Error updating contact:", error);
        throw error;
    }
};

export default api;
