export const validatePassword = (password) => {
    const minLength = 6;
    const hasNumber = /[0-9]/;
    if (password == ('' || null))
    {
        return "Hasło jest obowiązkowe!"
    }
    if (password.length < minLength) {
        return "Hasło musi mieć co najmniej 6 znaków i przynajmniej jedną cyfrę.";
    }
    if (!hasNumber.test(password)) {
        return "Hasło musi zawierać przynajmniej jedną cyfrę!";
    }
    return ""; // No error
};