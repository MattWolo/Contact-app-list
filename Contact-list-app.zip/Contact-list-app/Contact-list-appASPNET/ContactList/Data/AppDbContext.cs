﻿using ContactList.Model;
using Microsoft.EntityFrameworkCore;

namespace ContactList.Data
{
    // AppDbContext inherits from DbContext, which is a part of Entity Framework Core
    public class AppDbContext : DbContext
    {
        
        public DbSet<Contact> Contacts { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<SubCategory> SubCategories { get; set; }

        // Constructor that accepts DbContextOptions and passes them to the base class
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
            // No additional logic is needed in the constructor
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Seed initial data for the Categories table
            modelBuilder.Entity<Category>().HasData(
                new Category { Id = 1, Name = "Służbowy" },
                new Category { Id = 2, Name = "Prywatny" },
                new Category { Id = 3, Name = "Inny" }
            );

            // Seed initial data for the SubCategories table
            modelBuilder.Entity<SubCategory>().HasData(
                new SubCategory { Id = 1, Name = "Szef", CategoryId = 1 },
                new SubCategory { Id = 2, Name = "Klient", CategoryId = 1 }
            );
        }
    }
}
