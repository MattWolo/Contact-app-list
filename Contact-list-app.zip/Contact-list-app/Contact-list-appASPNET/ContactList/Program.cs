using ContactList.Data;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore; 
using Microsoft.IdentityModel.Tokens;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Read JWT secret key from configuration
var jwtSettings = builder.Configuration.GetSection("JwtSettings");
var secretKey = jwtSettings.GetValue<string>("SecretKey");

// Configuring JWT authentication as documentation guided
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme; // Set the default authentication scheme
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme; // Set the challenge scheme for unauthorized requests
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(secretKey)),
        ValidateIssuer = false,
        ValidateAudience = false
    };
});

builder.Services.AddAuthorization();

// Configure CORS (Cross-Origin Resource Sharing) as documentation guided
// >> Needed CORS since I was working on two ports localhost:3000 (React.js) and localhost:7049 (ASP.NET) <<
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigin",
        builder => builder.WithOrigins("https://localhost:3000") // Allow requests from this origin
                          .AllowAnyMethod()
                          .AllowAnyHeader()
                          .AllowCredentials());
});

builder.Services.AddControllers(); // Register MVC controllers

// Configure Swagger for API documentation as documentation guided
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(); // Enable Swagger generation

// Connection String
builder.Services.AddDbContext<AppDbContext>(options =>
{
    options.UseSqlServer
    ("Server=YOUR_SERVER_NAME;Database=ContactListDB;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=true");
});

var app = builder.Build(); // Build the web application

// Middleware for the application
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(); // Enable Swagger UI for interactive API documentation
}

app.UseHttpsRedirection(); // Redirect HTTP requests to HTTPS - I prefered to change from HTTP to HTTPS due to using axios later & transfer safety

// Use the defined CORS policy
app.UseCors("AllowSpecificOrigin");

// Add authentication and authorization middleware -> Self-made SSL, browsers will alert for sure.
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
