﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ContactList.Migrations
{
    /// <inheritdoc />
    public partial class AdjustedRegisterAndLogin : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "SubCategory",
                table: "Contacts",
                newName: "SubCategoryString");

            migrationBuilder.RenameColumn(
                name: "Category",
                table: "Contacts",
                newName: "PasswordSalt");

            migrationBuilder.AddColumn<string>(
                name: "CategoryString",
                table: "Contacts",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CategoryString",
                table: "Contacts");

            migrationBuilder.RenameColumn(
                name: "SubCategoryString",
                table: "Contacts",
                newName: "SubCategory");

            migrationBuilder.RenameColumn(
                name: "PasswordSalt",
                table: "Contacts",
                newName: "Category");
        }
    }
}
