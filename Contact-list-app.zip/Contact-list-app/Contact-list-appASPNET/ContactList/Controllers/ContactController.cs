﻿using ContactList.Data;
using ContactList.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;

namespace ContactList.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ContactController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Contact
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ContactDto>>> GetContacts()
        {
            var contacts = await _context.Contacts.ToListAsync();
            var contactDtos = contacts.Select(c => new ContactDto
            {
                Id = c.Id,
                FirstName = c.FirstName,
                LastName = c.LastName,
                Email = c.Email,
                PhoneNumber = c.PhoneNumber,
                CategoryString = c.CategoryString,
                SubCategoryString = c.SubCategoryString,
                DateOfBirth = c.DateOfBirth
            });
            return Ok(contactDtos);
        }

        // GET: api/Contact/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<ContactDto>> GetContact(int id)
        {
            var contact = await _context.Contacts.FindAsync(id);
            if (contact == null) return NotFound();
            var contactDto = new ContactDto
            {
                Id = contact.Id,
                FirstName = contact.FirstName,
                LastName = contact.LastName,
                Email = contact.Email,
                CategoryString = contact.CategoryString,
                SubCategoryString = contact.SubCategoryString,
                PhoneNumber = contact.PhoneNumber,
                DateOfBirth = contact.DateOfBirth
            };

            return Ok(contactDto);
        }

        // POST: api/Contact
        [HttpPost]
        public async Task<IActionResult> CreateContact(Contact contact)
        {
            _context.Contacts.Add(contact);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetContact), new { id = contact.Id }, contact);
        }

        // PUT: api/Contact/{id}
        [HttpPut("{id}")]
        [Authorize]
        public async Task<IActionResult> UpdateContact(int id, ContactUpdateDto updatedContact)
        {
            var contact = await _context.Contacts.FindAsync(id);
            if (contact == null)
                return NotFound("Nie znaleziono kontaktu");

            if (!string.IsNullOrEmpty(updatedContact.FirstName))
                contact.FirstName = updatedContact.FirstName;

            if (!string.IsNullOrEmpty(updatedContact.LastName))
                contact.LastName = updatedContact.LastName;

            if (!string.IsNullOrEmpty(updatedContact.Email))
                contact.Email = updatedContact.Email;

            if (!string.IsNullOrEmpty(updatedContact.CategoryString))
                contact.CategoryString = updatedContact.CategoryString;

            if (!string.IsNullOrEmpty(updatedContact.SubCategoryString))
                contact.SubCategoryString = updatedContact.SubCategoryString;

            if (!string.IsNullOrEmpty(updatedContact.PhoneNumber))
                contact.PhoneNumber = updatedContact.PhoneNumber;

            if (updatedContact.DateOfBirth != null)
                contact.DateOfBirth = (DateOnly)updatedContact.DateOfBirth;

            try
            {
                await _context.SaveChangesAsync();
                return NoContent();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Contacts.Any(e => e.Id == id))
                    return NotFound("Nie znaleziono kontaktu w trakcie aktualizacji listy");

                throw;
            }
        }

        // DELETE: api/Contact/{id}
        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteContact(int id)
        {
            var contact = await _context.Contacts.FindAsync(id);
            if (contact == null)
                return NotFound("Nie znaleziono kontaktu");

            _context.Contacts.Remove(contact);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // Category & subCategory validation
        private async Task<bool> ValidateCategoryAndSubCategory(Contact contact)
        {
            //  check if Category exist
            var validCategory = await _context.Categories.AnyAsync(c => c.Name == contact.CategoryString);
            if (!validCategory) return false;

            if (contact.CategoryString == "Służbowy")
            {
                return await _context.SubCategories.AnyAsync(sc => sc.Name == contact.SubCategoryString);
            }

            //When Category = "inny", allow text input for anything
            return true;
        }
    }
}