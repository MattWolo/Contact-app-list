﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using ContactList.Data;
using ContactList.Model;
using Microsoft.AspNetCore.Authorization;

namespace ContactList.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _context; // Database context for accessing contacts
        private readonly IConfiguration _configuration; // Configuration settings for JWT

        public AuthController(AppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(ContactRegisterDto dto)
        {
            // Check if the email is already in use
            if (await _context.Contacts.AnyAsync(u => u.Email == dto.Email))
            {
                return BadRequest("Email jest już w użyciu.");
            }

            // Generate a salt and hash the password
            var salt = new byte[128 / 8];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }

            string hashedPassword = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: dto.Password,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: 10000,
                numBytesRequested: 256 / 8));

            // Create a new contact with hashed password
            var newContact = new Contact
            {
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Email = dto.Email,
                Password = hashedPassword,
                PasswordSalt = Convert.ToBase64String(salt),
                CategoryString = dto.CategoryString,
                SubCategoryString = dto.SubCategoryString,
                PhoneNumber = dto.PhoneNumber,
                DateOfBirth = dto.DateOfBirth
            };

            // Add the new contact to the database
            _context.Contacts.Add(newContact);
            await _context.SaveChangesAsync();

            return Ok("Kontakt zarejestrowany poprawnie.");
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(ContactLoginDto dto)
        {
            // Find the contact by email
            var contact = await _context.Contacts.SingleOrDefaultAsync(u => u.Email == dto.Email);
            if (contact == null)
            {
                return Unauthorized("Nieprawidłowy e-mail lub hasło.");
            }

            // Hash the provided password and compare it with the stored hash
            string hashedPassword = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: dto.Password,
                salt: Convert.FromBase64String(contact.PasswordSalt),
                prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: 10000,
                numBytesRequested: 256 / 8));

            if (hashedPassword != contact.Password)
            {
                return Unauthorized("Nieprawidłowy e-mail lub hasło.");
            }

            // Generate JWT token for the authenticated user
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_configuration["JwtSettings:SecretKey"]);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, contact.Id.ToString()) // Claims for token
                }),
                Expires = DateTime.UtcNow.AddHours(1), // Token expiration time
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor); // Create token
            string jwtToken = tokenHandler.WriteToken(token); // Write token as string

            return Ok(new { Token = jwtToken }); // Return the JWT token
        }
    }
}
