﻿public class ContactUpdateDto
{
    //All fields aren't necessary
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? Email { get; set; }
    public string? CategoryString { get; set; }
    public string? SubCategoryString { get; set; }
    public string? PhoneNumber { get; set; }
    public DateOnly? DateOfBirth { get; set; }
}